<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
class Users_Model extends CI_Model{
	
	public function __construct() {
		parent::__construct(); 
	}
	
	public function getData($rowno,$rowperpage,$search="") 
	{	
		$this->db->select('*');
		$this->db->from('users');
		
		if($search != ''){
			$this->db->like('name', $search);
		}
		$this->db->limit($rowperpage, $rowno); 
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		
		return $query->result_array();  
	}
	
	// Select total records
	function getrecordCount($search = '') 
	{
		$this->db->select('count(*) as allcount');
		$this->db->from('users');

		if($search != ''){
			$this->db->like('name', $search);
		}

		$query = $this->db->get();
		$result = $query->result_array();

		return $result[0]['allcount'];
	}

}


