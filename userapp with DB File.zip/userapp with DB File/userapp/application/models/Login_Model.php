<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
class Login_Model extends CI_Model{
	
	public function __construct() {
		parent::__construct(); 
	}
	
	public function getUser($email,$pass)
	{	
		$this->db->select('*');
		$this->db->from('users');
		
		if($email != ''){
			$this->db->where('email', $email);
		}
		
		if($pass != ''){
			$this->db->where('password', md5($pass));
		}
		
		$query = $this->db->get();
		
		if($query->num_rows()>0)
		{
			return "success";
		}else{
			return "failed";
		}
		 
	}
	

}


