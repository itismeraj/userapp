<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>User App</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="form-group col-xs-12 col-sm-4 col-lg-8">
					<h4>App</h4> 
				</div>
				
				<div class="form-group col-xs-12 col-sm-4 col-lg-2">
					<h4> Welcome <?php echo $this->session->userdata('email'); ?></h4>
				</div>
				
				<div class="form-group col-xs-12 col-sm-4 col-lg-2">
					<a href="<?php echo site_url('login/logout'); ?>">
						<input type='Logout' class="btn btn-primary form-control" name='Logout' value='Logout'>
					</a>
				</div>
				
			</div>
			<hr />  
			<!-- Search form (start) -->
			<div class="row">	
				<form method='post' class="form" action="<?= base_url() ?>users/getAllUsers" >
					<div class="form-group col-xs-12 col-sm-6 col-md-5 col-lg-4">
						<input type='text' name='search' class="form-control" placeholder="Search by Name" value='<?= $search ?>'>
					</div>
					
					<div class="form-group col-xs-12 col-sm-6 col-md-2 col-lg-2">
						<input type='submit' class="btn btn-primary form-control" name='submit' value='Search'>
					</div>
					
				</form>
				
				<div class="form-group col-xs-12 col-sm-6 col-md-2 col-lg-2">
					<form method='post' class="form" action="<?= base_url() ?>users/getAllUsers" >
						<a href="<?php echo site_url('users/getAllUsers'); ?>">
							<input type='submit' class="btn btn-primary form-control" name='Reset' value='Reset'>
						</a>
					</form>
				</div>
				
				
			</div>
			<br/>
				
			<div class="row">
				<div class="col-md-12">
					
					<!--- Success Message --->
					<?php if ($this->session->flashdata('success')) { ?> 
					<p style="font-size: 20px; color:green"><?php echo $this->session->flashdata('success'); ?></p>
					<?php }?>
					<!---- Error Message ---->
					<?php if ($this->session->flashdata('error')) { ?>
					<p style="font-size: 20px; color:red"><?php echo $this->session->flashdata('error'); ?></p>
					<?php } ?> 

					
					<div class="table-responsive">                
						<table id="mytable" class="table table-bordred table-striped">                 
							<thead>
								<th>S.No</th>
								<th>ID</th>
								<th>User Name</th>
								<th>email</th>
							</thead>
							<tbody>    
								<?php 
									if(count($result) != 0){
										$cnt=1;
										foreach($result as $row)
										{               
											?>  
											<tr>
												<td><?php echo htmlentities($cnt); ?></td>
												<td><?php echo htmlentities($row["id"]); ?></td>
												<td><?php echo htmlentities($row["name"]); ?></td>
												<td><?php echo htmlentities($row["email"]); ?></td>
											</tr>
											<?php 
											// for serial number increment
											$cnt++;
										} 
								}else{
									echo "<tr>";
									echo "<td colspan='6'>No record found.</td>";
									echo "</tr>";
								} ?>
							</tbody>      
						</table>
					</div>
					
					<!-- Paginate -->
					<div style='margin-top: 10px;'>
						<?php echo $pagination; ?>
					</div>
				   
				</div>
			</div>
		</div>
	</body>
</html>
