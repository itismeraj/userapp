<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class Users extends CI_Controller{
	
	public function __construct(){
 
		parent::__construct();
		$this->load->helper('url');

		// Load session
		$this->load->library('session');

		// Load Pagination library
		$this->load->library('pagination');

		// Load model
		$this->load->model('Users_Model');
	}
	
	public function index(){
		redirect('Users/getAllUsers');
	}
	
	// for all records
	public function getAllUsers($rowno=0)
	{
		// Search text 
		$search_text = "";
		
		if($this->input->post('submit') != NULL ){
			$search_text = $this->input->post('search');
			$this->session->set_userdata(array("search"=>$search_text));
		}
		
		if($this->input->post('Reset') != NULL ){
			$this->session->unset_userdata('search_text'); 
			$search_text = "";
		}
			
		// Row per page
		$rowperpage = 5;

		// Row position
		if($rowno != 0){
		  $rowno = ($rowno-1) * $rowperpage;
		}
	 
		// All records count
		$allcount = $this->Users_Model->getrecordCount($search_text);

		// Get records
		$results = $this->Users_Model->getData($rowno,$rowperpage,$search_text);
	 
		// Pagination Configuration
		$config['base_url'] = base_url().'users/getAllUsers';
		$config['use_page_numbers'] = TRUE;
		$config['total_rows'] = $allcount;
		$config['per_page'] = $rowperpage;
		
		$config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tagl_close'] = '</a></li>';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tagl_close'] = '</li>';
        $config['first_tag_open'] = '<li class="page-item disabled">';
        $config['first_tagl_close'] = '</li>';
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tagl_close'] = '</a></li>';
        $config['attributes'] = array('class' => 'page-link');

		// Initialize
		$this->pagination->initialize($config);
	 
		$data['pagination'] = $this->pagination->create_links();
		$data['result'] = $results;
		$data['row'] = $rowno;
		$data['search'] = $search_text;
		
		// Load view
		$this->load->view('users',$data);
	}
	
	
}
