<?php  
defined('BASEPATH') OR exit('No direct script access allowed');  
  
class Login extends CI_Controller {  
	
	public function __construct(){
 
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('email');
		// Load model
		$this->load->model('Login_Model');
	}
      
    public function index()  
    {  
        $this->load->view('login_view');  
    }
	
	public function password_check($str)
	{
	   if (preg_match('#[\W]{1}#', $str) && preg_match('#[A-Z]{1}#', $str)) {
		 return TRUE;
	   }
	   return FALSE;
	}
	
    public function userLogin()  
    {  
		$this->form_validation->set_rules('email','email','trim|required|valid_email');
		$this->form_validation->set_rules('password','password','trim|required|max_length[6]|callback_password_check');
		
		if($this->form_validation->run()){
			$email = $this->input->post('email');  
			$pass = $this->input->post('password'); 
			
			$results = $this->Login_Model->getUser($email,$pass);
			
			if ($results=='success')   
			{  
				//declaring session  
				$this->session->set_userdata(array('email'=>$email)); 
				redirect("users/index");  
			}  
			else{  
				$data['error'] = 'Your email are password is wrong';  
				$this->load->view('login_view', $data);  
			} 
			
		} else {
			$this->load->view('login_view');
		}
    }
	
    public function logout()  
    {  
        //removing session  
        $this->session->unset_userdata('email');  
        redirect("Login");  
    }  
  
}  
?>  
