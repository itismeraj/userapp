userapp is devloped by Meraj Ahmad.
+91 - 8495806215

Note : 

1. Default controller is Login.
2. database Name is userapp
3. DB username is root without paasword.
4. table name is users.
5. added db sql file into userapp\db folder
6. for login email can be "m@gmail.com" and paasword will be md5 hash "Me@123".
7. CI version is 3.1.8


